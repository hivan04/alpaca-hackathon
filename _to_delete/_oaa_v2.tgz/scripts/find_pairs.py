#!/usr/bin/env python3
"""Offline cointegration screen -> config/pairs.yaml.

Run this before the agent trades, and again if the market regime shifts. It is
deliberately a separate script rather than part of the live loop: re-testing
cointegration at 15:45 is how you conjure a pair into existence in the evening
and lose money on it at the open.

    python scripts/find_pairs.py                       # screen the default candidates
    python scripts/find_pairs.py --write               # write config/pairs.yaml
    python scripts/find_pairs.py --symbols XLE XOP KO PEP --lookback 500 --write
    python scripts/find_pairs.py --provider alpaca     # use the SDK instead of the CLI

Data comes through the configured provider, which defaults to the Alpaca CLI —
the same binary that executes the orders.
"""

from __future__ import annotations

import argparse
import datetime as dt
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import yaml  # noqa: E402

from oaa.config.loader import load_settings  # noqa: E402
from oaa.core.logging import setup_logging  # noqa: E402
from oaa.data.factory import get_data_provider  # noqa: E402
from oaa.quant.cointegration import find_pairs  # noqa: E402

# Economically linked, options-liquid, shortable. The screen decides what
# actually survives; this is only where it starts looking.
DEFAULT_CANDIDATES = [
    "XLE", "XOP", "XLF", "KRE", "XLK", "QQQ", "SPY", "IWM",
    "KO", "PEP", "XOM", "CVX", "HD", "LOW", "MA", "V", "GS", "MS",
    "UPS", "FDX", "CAT", "DE", "T", "VZ",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbols", nargs="+", default=DEFAULT_CANDIDATES)
    parser.add_argument("--lookback", type=int, default=500, help="Trading days of history")
    parser.add_argument("--max-pvalue", type=float, default=0.05)
    parser.add_argument("--min-correlation", type=float, default=0.70)
    parser.add_argument("--min-half-life", type=float, default=1.0)
    parser.add_argument("--max-half-life", type=float, default=30.0)
    parser.add_argument("--top", type=int, default=10, help="Keep the N strongest pairs")
    parser.add_argument("--provider", default=None, help="Override the data provider (cli|alpaca)")
    parser.add_argument("--profile", default=None)
    parser.add_argument("--write", action="store_true", help="Write config/pairs.yaml")
    parser.add_argument("--out", default="config/pairs.yaml")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    settings = load_settings(profile=args.profile)
    setup_logging(settings.config.telemetry.log_level, "console")
    if args.provider:
        settings.config.data.provider = args.provider

    provider = get_data_provider(settings.config, settings.credentials)
    print(f"Fetching {args.lookback}d of daily bars for {len(args.symbols)} symbols "
          f"via '{provider.name}'...")

    closes: dict[str, list[float]] = {}
    for symbol in args.symbols:
        try:
            bars = provider.bars(symbol, lookback_days=args.lookback, timeframe="1Day")
            closes[symbol] = [float(b["close"]) for b in bars]
            print(f"  {symbol:<6} {len(bars):>4} bars")
        except Exception as exc:  # noqa: BLE001
            print(f"  {symbol:<6} SKIPPED ({exc})")

    if len(closes) < 2:
        print("\nNot enough symbols with data to screen. Check credentials and the CLI install.")
        return 1

    print("\nScreening...")
    results = find_pairs(
        closes,
        max_pvalue=args.max_pvalue,
        min_correlation=args.min_correlation,
        half_life_range=(args.min_half_life, args.max_half_life),
        min_observations=min(250, args.lookback // 2),
        top_n=args.top,
    )

    if not results:
        print("\nNo pair passed the screen. That is a real answer, not a bug —\n"
              "loosen --max-pvalue or widen the half-life range only if you can\n"
              "justify it, and remember a marginal pair is a directional bet.")
        return 2

    print(f"\n{len(results)} pair(s) passed:\n")
    header = f"{'PAIR':<14}{'P-VALUE':>10}{'HEDGE':>9}{'CORR':>8}{'HALF-LIFE':>12}"
    print(header)
    print("-" * len(header))
    for r in results:
        hl = f"{r.half_life_days:.1f}d" if r.half_life_days else "n/a"
        print(f"{r.name:<14}{r.pvalue:>10.5f}{r.hedge_ratio:>9.3f}"
              f"{r.correlation:>8.3f}{hl:>12}")

    if not args.write:
        print("\n(dry run — pass --write to update config/pairs.yaml)")
        return 0

    payload = {
        "screened_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "lookback_days": args.lookback,
        "criteria": {
            "max_pvalue": args.max_pvalue,
            "min_correlation": args.min_correlation,
            "half_life_days": [args.min_half_life, args.max_half_life],
            "min_observations": min(250, args.lookback // 2),
        },
        "pairs": [
            {
                "left": r.left,
                "right": r.right,
                "hedge_ratio": round(r.hedge_ratio, 6),
                "pvalue": round(r.pvalue, 6),
                "half_life_days": round(r.half_life_days, 2) if r.half_life_days else None,
                "correlation": round(r.correlation, 4),
                "enabled": True,
                "notes": f"screened {dt.date.today().isoformat()}",
            }
            for r in results
        ],
    }
    out_path = ROOT / args.out
    header_comment = (
        "# GENERATED by scripts/find_pairs.py - do not hand-edit.\n"
        "# Regenerate with: python scripts/find_pairs.py --write\n"
    )
    out_path.write_text(header_comment + yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    print(f"\nWrote {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
