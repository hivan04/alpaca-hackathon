"""End-to-end smoke: the whole pipeline against the simulator, no network."""

from __future__ import annotations

import datetime as dt

import pytest

from oaa.brokers.sim import SimBroker
from oaa.config.loader import load_settings
from oaa.core.types import MarketContext
from oaa.data.base import MarketDataProvider


class FakeData(MarketDataProvider):
    """Serves the synthetic chain fixture so the loop can run offline."""

    name = "fake"

    def __init__(self, cfg, chain, bars):
        super().__init__(cfg)
        self._chain = chain
        self._bars = bars

    def spot(self, symbol): return 500.0

    def bars(self, symbol, lookback_days=90, timeframe="1Day"): return self._bars

    def option_chain(self, symbol, **kwargs): return self._chain

    def context(self, symbol, lookback_days=90):
        return MarketContext(
            symbol=symbol,
            asof=dt.datetime(2026, 9, 1, 15, 0, tzinfo=dt.timezone.utc),
            spot=500.0,
            bars=self._bars,
            chain=self._chain,
            realised_vol=0.14,
            implied_vol=0.20,
            iv_rank=0.70,
            trend_strength=0.10,
            adx=15.0,
        )


@pytest.fixture
def settings(tmp_path):
    s = load_settings(profile="dev")
    s.config.universe.symbols = ["SPY"]
    s.config.agents.llm.provider = None      # rules-only, no API key needed
    s.config.execution.dry_run = True
    s.config.telemetry.run_dir = str(tmp_path)
    s.config.telemetry.journal = str(tmp_path / "journal.jsonl")
    s.config.telemetry.db = str(tmp_path / "oaa.sqlite")
    s.config.telemetry.equity_curve = str(tmp_path / "equity.csv")
    s.config.agents.memory.path = str(tmp_path / "memory.sqlite")
    return s


def test_full_cycle_runs_dry_without_network(settings, chain, bars):
    from oaa.agents.orchestrator import Orchestrator

    for strategy in settings.config.strategies:
        strategy.params["universe"] = ["SPY"]

    broker = SimBroker(settings.config)
    orch = Orchestrator(settings, broker, FakeData(settings.config, chain, bars))
    try:
        result = orch.run_cycle("scan_and_trade", "smoke")
        assert result.symbols_scanned == 1
        assert result.ideas_generated >= 1
        assert not result.errors
        # Dry run: decisions recorded, no cash moved.
        assert orch.journal.counts()["decisions"] >= 1
        assert broker.cash == broker.starting_cash
    finally:
        orch.close()


def test_status_reports_the_wiring(settings, chain, bars):
    from oaa.agents.orchestrator import Orchestrator

    broker = SimBroker(settings.config)
    orch = Orchestrator(settings, broker, FakeData(settings.config, chain, bars))
    try:
        status = orch.status()
        assert status["profile"] == "dev"
        assert status["dry_run"] is True
        assert "vol_carry_condor" in status["strategies"]
    finally:
        orch.close()


def test_manage_cycle_closes_a_position_at_its_profit_target(settings, chain, bars):
    from oaa.agents.orchestrator import Orchestrator
    from oaa.core.types import PositionSnapshot

    settings.config.execution.dry_run = False
    broker = SimBroker(settings.config)
    broker._positions["SPY260918C00500000"] = PositionSnapshot(
        symbol="SPY260918C00500000", qty=1, avg_entry_price=5.0,
        market_value=800.0, unrealized_pl=300.0, unrealized_plpc=0.60,
        underlying="SPY", expiry=dt.date(2026, 9, 18),
    )
    orch = Orchestrator(settings, broker, FakeData(settings.config, chain, bars))
    try:
        result = orch.run_cycle("manage_positions", "smoke-manage")
        assert result.positions_closed == 1
    finally:
        orch.close()
