from __future__ import annotations

import datetime as dt

import pytest

from oaa.config.schema import Config
from oaa.core.types import AccountSnapshot, Greeks, OptionQuote, Right
from oaa.options.occ import build_occ


@pytest.fixture
def cfg() -> Config:
    return Config()


@pytest.fixture
def today() -> dt.date:
    return dt.date(2026, 9, 1)


def make_quote(
    root: str = "SPY",
    expiry: dt.date | None = None,
    strike: float = 500.0,
    right: Right = Right.CALL,
    bid: float = 1.00,
    ask: float = 1.10,
    delta: float | None = 0.30,
    iv: float | None = 0.20,
    oi: int = 5000,
) -> OptionQuote:
    expiry = expiry or dt.date(2026, 9, 18)
    return OptionQuote(
        symbol=build_occ(root, expiry, right, strike),
        underlying=root,
        expiry=expiry,
        strike=strike,
        right=right,
        bid=bid,
        ask=ask,
        implied_volatility=iv,
        greeks=Greeks(delta=delta, gamma=0.01, theta=-0.05, vega=0.2),
        open_interest=oi,
        volume=500,
    )


def _bs(spot: float, strike: float, t_years: float, vol: float, is_call: bool):
    """Black-Scholes price and delta. The test chain has to be arbitrage-free
    enough that spread widths and credit/width ratios come out realistic -
    a hand-waved price grid makes strategy tests meaningless."""
    import math

    if t_years <= 0 or vol <= 0:
        intrinsic = max(0.0, spot - strike) if is_call else max(0.0, strike - spot)
        return intrinsic, (1.0 if intrinsic > 0 else 0.0) * (1 if is_call else -1)

    def cdf(x: float) -> float:
        return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

    sqrt_t = math.sqrt(t_years)
    d1 = (math.log(spot / strike) + 0.5 * vol * vol * t_years) / (vol * sqrt_t)
    d2 = d1 - vol * sqrt_t
    if is_call:
        return spot * cdf(d1) - strike * cdf(d2), cdf(d1)
    return strike * cdf(-d2) - spot * cdf(-d1), cdf(d1) - 1.0


@pytest.fixture
def chain(today: dt.date) -> list[OptionQuote]:
    """A synthetic but arbitrage-free SPY chain: spot 500, 21 DTE, 20% vol,
    strikes 400-600 on the 5-point grid, a realistic 5c-wide market."""
    expiry = today + dt.timedelta(days=21)
    spot, vol = 500.0, 0.20
    t_years = 21 / 365
    quotes: list[OptionQuote] = []
    for strike in range(400, 605, 5):
        for right in (Right.CALL, Right.PUT):
            price, delta = _bs(spot, float(strike), t_years, vol, right is Right.CALL)
            if price < 0.15:
                continue
            half = max(0.02, round(price * 0.01, 2))
            quotes.append(
                make_quote(
                    expiry=expiry,
                    strike=float(strike),
                    right=right,
                    bid=round(price - half, 2),
                    ask=round(price + half, 2),
                    delta=round(delta, 4),
                    iv=vol,
                    oi=5000,
                )
            )
    return quotes


@pytest.fixture
def account() -> AccountSnapshot:
    return AccountSnapshot(
        account_id="TEST",
        equity=100_000.0,
        last_equity=100_000.0,
        cash=100_000.0,
        buying_power=100_000.0,
        options_buying_power=100_000.0,
        options_trading_level=3,
    )


@pytest.fixture
def bars() -> list[dict]:
    """90 daily bars trending gently up with realistic intrabar range."""
    out = []
    price = 100.0
    for i in range(90):
        price *= 1.0 + (0.004 if i % 3 else -0.002)
        out.append({
            "timestamp": dt.datetime(2026, 6, 1) + dt.timedelta(days=i),
            "open": price * 0.998,
            "high": price * 1.008,
            "low": price * 0.992,
            "close": price,
            "volume": 1_000_000 + i * 1000,
        })
    return out
