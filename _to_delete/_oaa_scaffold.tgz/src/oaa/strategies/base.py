"""Strategy contract.

A strategy is a pure function of a MarketContext: it sees a snapshot and
returns zero or more TradeIdeas. It does not size them (risk does that), does
not price the order (execution does that), and never calls the broker.

That separation is what lets the same strategy code run live and in backtest.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any

from oaa.config.schema import Config, StrategyRef
from oaa.core.errors import StrategyError
from oaa.core.logging import get_logger
from oaa.core.registry import Registry
from oaa.core.types import AccountSnapshot, MarketContext, TradeIdea
from oaa.options.chain import ChainFilter, ChainView
from oaa.options.structures import StructureBuilder

log = get_logger("strategies")


@dataclass
class StrategyContext:
    """Everything a strategy is allowed to see for one symbol."""

    market: MarketContext
    account: AccountSnapshot
    config: Config
    params: dict[str, Any] = field(default_factory=dict)

    def chain_view(self, chain_filter: ChainFilter | None = None) -> ChainView:
        opts = self.config.options
        cf = chain_filter or ChainFilter(
            min_dte=opts.min_days_to_expiry,
            max_dte=opts.max_days_to_expiry,
            min_open_interest=opts.min_open_interest,
            min_volume=opts.min_volume,
            max_spread_pct=opts.max_bid_ask_spread_pct,
            min_price=opts.min_option_price,
            max_price=opts.max_option_price,
        )
        return ChainView.from_quotes(
            symbol=self.market.symbol,
            spot=self.market.spot,
            quotes=self.market.chain,
            chain_filter=cf,
            asof=self.market.asof.date(),
        )

    def has_position_in(self, symbol: str) -> bool:
        return bool(self.account.by_underlying(symbol))


class Strategy(abc.ABC):
    """Base class. Subclasses implement `generate`."""

    registry_name: str = "base"
    description: str = ""

    def __init__(self, ref: StrategyRef, config: Config) -> None:
        self.ref = ref
        self.config = config
        self.params: dict[str, Any] = ref.params or {}
        self.weight = ref.weight

    @property
    def name(self) -> str:
        return self.ref.name

    # -- the one method that matters ---------------------------------------- #
    @abc.abstractmethod
    def generate(self, ctx: StrategyContext) -> list[TradeIdea]:
        """Return candidate structures. Empty list is a perfectly good answer."""

    # -- optional hooks ------------------------------------------------------ #
    def should_exit(self, ctx: StrategyContext, idea: TradeIdea, pnl_pct: float) -> str | None:
        """Return an exit reason, or None to hold.

        Default: the profit target and stop loss from `management` in the YAML.
        """
        mgmt = self.config.management
        exit_cfg = self.params.get("exit", {})
        target = exit_cfg.get("profit_target_pct", mgmt.profit_target_pct)
        stop = exit_cfg.get("stop_loss_pct", mgmt.stop_loss_pct)
        if pnl_pct >= target:
            return f"profit target {target:.0%} reached ({pnl_pct:.0%})"
        if pnl_pct <= -abs(stop):
            return f"stop loss {stop:.0%} hit ({pnl_pct:.0%})"
        return None

    def universe(self) -> list[str]:
        """Symbols this strategy wants. Defaults to the global universe."""
        symbols = self.params.get("universe")
        if symbols:
            return [s.upper() for s in symbols]
        return self.config.universe.active()

    # -- convenience --------------------------------------------------------- #
    def builder(self, ctx: StrategyContext) -> StructureBuilder:
        view = ctx.chain_view()
        if view.is_empty:
            raise StrategyError(
                f"{ctx.market.symbol}: no contracts survived the liquidity filter"
            )
        return StructureBuilder(view=view, strategy=self.name)

    def p(self, path: str, default: Any = None) -> Any:
        """Dotted lookup into the strategy's YAML params. p('entry.min_iv_rank')"""
        cursor: Any = self.params
        for part in path.split("."):
            if not isinstance(cursor, dict) or part not in cursor:
                return default
            cursor = cursor[part]
        return cursor


strategy_registry: Registry[Strategy] = Registry("strategy")


def load_strategies(config: Config) -> list[Strategy]:
    """Instantiate every enabled strategy named in the config."""
    strategy_registry.autoload("oaa.strategies")
    loaded: list[Strategy] = []
    for ref in config.enabled_strategies():
        cls = strategy_registry.get(ref.name)
        loaded.append(cls(ref, config))
        log.debug("loaded strategy %s (weight %.2f)", ref.name, ref.weight)
    if not loaded:
        log.warning("no strategies enabled - the agent will not open anything")
    return loaded
