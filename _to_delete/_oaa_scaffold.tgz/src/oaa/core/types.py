"""The domain model.

These types are the contract between layers. A strategy emits a TradeIdea; the
risk engine turns it into a RiskVerdict; the executor turns an approved idea
into an OrderTicket; the broker returns Fills. No layer reaches past its
neighbour, which is what makes any one of them swappable.
"""

from __future__ import annotations

import datetime as dt
import uuid
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, computed_field


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=False)


# --------------------------------------------------------------------------- #
# enums
# --------------------------------------------------------------------------- #
class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"

    @property
    def opposite(self) -> Side:
        return Side.SELL if self is Side.BUY else Side.BUY


class Right(str, Enum):
    CALL = "call"
    PUT = "put"


class Intent(str, Enum):
    BUY_TO_OPEN = "buy_to_open"
    BUY_TO_CLOSE = "buy_to_close"
    SELL_TO_OPEN = "sell_to_open"
    SELL_TO_CLOSE = "sell_to_close"

    @classmethod
    def opening(cls, side: Side) -> Intent:
        return cls.BUY_TO_OPEN if side is Side.BUY else cls.SELL_TO_OPEN

    @classmethod
    def closing(cls, side: Side) -> Intent:
        return cls.BUY_TO_CLOSE if side is Side.BUY else cls.SELL_TO_CLOSE


class StructureType(str, Enum):
    """Every structure here has a bounded maximum loss by construction."""

    SINGLE_LONG = "single_long"
    VERTICAL_DEBIT = "vertical_debit"
    VERTICAL_CREDIT = "vertical_credit"
    IRON_CONDOR = "iron_condor"
    IRON_BUTTERFLY = "iron_butterfly"
    CALENDAR = "calendar"
    DIAGONAL = "diagonal"
    STRADDLE = "straddle"
    STRANGLE = "strangle"
    RATIO = "ratio"

    @property
    def is_defined_risk(self) -> bool:
        return self not in {
            StructureType.STRADDLE,
            StructureType.STRANGLE,
            StructureType.RATIO,
        }


class DecisionAction(str, Enum):
    OPEN = "open"
    CLOSE = "close"
    ADJUST = "adjust"
    HOLD = "hold"
    SKIP = "skip"


# --------------------------------------------------------------------------- #
# market data
# --------------------------------------------------------------------------- #
class Greeks(Model):
    delta: float | None = None
    gamma: float | None = None
    theta: float | None = None
    vega: float | None = None
    rho: float | None = None


class OptionQuote(Model):
    """One contract, as we see it right now."""

    symbol: str
    underlying: str
    expiry: dt.date
    strike: float
    right: Right
    bid: float | None = None
    ask: float | None = None
    last: float | None = None
    implied_volatility: float | None = None
    greeks: Greeks = Field(default_factory=Greeks)
    open_interest: int | None = None
    volume: int | None = None
    asof: dt.datetime | None = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def mid(self) -> float | None:
        if self.bid is not None and self.ask is not None and self.ask > 0:
            return round((self.bid + self.ask) / 2, 4)
        return self.last

    @computed_field  # type: ignore[prop-decorator]
    @property
    def spread_pct(self) -> float | None:
        mid = self.mid
        if mid and self.bid is not None and self.ask is not None and mid > 0:
            return round((self.ask - self.bid) / mid, 4)
        return None

    def dte(self, asof: dt.date | None = None) -> int:
        return (self.expiry - (asof or dt.date.today())).days

    def is_liquid(self, max_spread_pct: float, min_oi: int, min_volume: int) -> bool:
        if self.bid is None or self.ask is None or self.bid <= 0:
            return False
        if self.spread_pct is None or self.spread_pct > max_spread_pct:
            return False
        if self.open_interest is not None and self.open_interest < min_oi:
            return False
        if self.volume is not None and self.volume < min_volume:
            return False
        return True


class MarketContext(Model):
    """Everything a strategy is allowed to look at for one underlying.

    Strategies read this snapshot and nothing else - no live calls from inside
    a strategy. That keeps them deterministic and cheap to backtest.
    """

    symbol: str
    asof: dt.datetime
    spot: float
    prev_close: float | None = None
    bars: list[dict[str, Any]] = Field(default_factory=list)
    chain: list[OptionQuote] = Field(default_factory=list)
    realised_vol: float | None = None
    implied_vol: float | None = None
    iv_rank: float | None = None
    trend_strength: float | None = None
    adx: float | None = None
    volume_ratio: float | None = None
    earnings_date: dt.date | None = None
    news: list[dict[str, Any]] = Field(default_factory=list)
    # Technology-partner adapters write here. Core code never assumes a key.
    enrichment: dict[str, Any] = Field(default_factory=dict)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def iv_rv_ratio(self) -> float | None:
        if self.implied_vol and self.realised_vol and self.realised_vol > 0:
            return round(self.implied_vol / self.realised_vol, 4)
        return None

    def expiries(self) -> list[dt.date]:
        return sorted({q.expiry for q in self.chain})


class Signal(Model):
    """A strategy's directional/vol read, before it becomes a structure."""

    symbol: str
    source: str
    direction: Literal["bullish", "bearish", "neutral"] = "neutral"
    strength: float = 0.0  # 0..1
    horizon_days: int = 21
    rationale: str = ""
    features: dict[str, float] = Field(default_factory=dict)


# --------------------------------------------------------------------------- #
# trade construction
# --------------------------------------------------------------------------- #
class Leg(Model):
    symbol: str            # OCC symbol
    side: Side
    ratio: int = 1
    intent: Intent | None = None
    quote: OptionQuote | None = None
    limit_price: float | None = None

    def resolved_intent(self, closing: bool = False) -> Intent:
        if self.intent:
            return self.intent
        return Intent.closing(self.side) if closing else Intent.opening(self.side)


class TradeIdea(Model):
    """A fully-specified, priced structure a strategy wants to put on."""

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    created_at: dt.datetime = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    symbol: str
    strategy: str
    structure: StructureType
    legs: list[Leg]
    quantity: int = 1
    # Positive = net debit paid, negative = net credit received (Alpaca's
    # convention for multi-leg limit prices).
    net_price: float = 0.0
    max_loss: float | None = None       # per structure, in dollars
    max_profit: float | None = None
    probability_of_profit: float | None = None
    thesis: str = ""
    confidence: float = 0.5
    score: float | None = None
    tags: list[str] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_credit(self) -> bool:
        return self.net_price < 0

    @computed_field  # type: ignore[prop-decorator]
    @property
    def leg_count(self) -> int:
        return len(self.legs)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def total_risk(self) -> float | None:
        """Dollar risk for the whole order, not one structure."""
        return None if self.max_loss is None else round(self.max_loss * self.quantity, 2)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def reward_risk(self) -> float | None:
        if self.max_loss and self.max_profit and self.max_loss > 0:
            return round(self.max_profit / self.max_loss, 3)
        return None

    def net_cash(self) -> float:
        """Signed dollars: negative = cash leaves the account."""
        return round(-self.net_price * 100 * self.quantity, 2)

    def describe(self) -> str:
        legs = " / ".join(f"{leg.side.value[0].upper()}{leg.ratio} {leg.symbol}" for leg in self.legs)
        kind = "credit" if self.is_credit else "debit"
        return (
            f"{self.symbol} {self.structure.value} x{self.quantity} "
            f"@ {abs(self.net_price):.2f} {kind} [{legs}]"
        )


class RiskVerdict(Model):
    approved: bool
    reasons: list[str] = Field(default_factory=list)
    adjusted_quantity: int | None = None
    checks: dict[str, bool] = Field(default_factory=dict)
    stamp: str | None = None   # execution refuses tickets without this

    @classmethod
    def approve(cls, quantity: int, checks: dict[str, bool] | None = None) -> RiskVerdict:
        return cls(
            approved=True,
            adjusted_quantity=quantity,
            checks=checks or {},
            stamp=uuid.uuid4().hex[:16],
        )

    @classmethod
    def reject(cls, reason: str, checks: dict[str, bool] | None = None) -> RiskVerdict:
        return cls(approved=False, reasons=[reason], checks=checks or {})


class OrderTicket(Model):
    """What actually goes to the broker."""

    idea_id: str
    client_order_id: str
    symbol: str
    legs: list[Leg]
    quantity: int
    order_type: Literal["limit", "market"] = "limit"
    limit_price: float | None = None
    time_in_force: Literal["day", "gtc"] = "day"
    risk_stamp: str | None = None
    dry_run: bool = False

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_multileg(self) -> bool:
        return len(self.legs) > 1


class Fill(Model):
    order_id: str
    client_order_id: str | None = None
    symbol: str
    status: str
    filled_qty: float = 0.0
    filled_avg_price: float | None = None
    submitted_at: dt.datetime | None = None
    filled_at: dt.datetime | None = None
    legs: list[dict[str, Any]] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def is_filled(self) -> bool:
        return self.status in {"filled", "partially_filled"}


# --------------------------------------------------------------------------- #
# account state
# --------------------------------------------------------------------------- #
class PositionSnapshot(Model):
    symbol: str
    qty: float
    avg_entry_price: float
    market_value: float = 0.0
    unrealized_pl: float = 0.0
    unrealized_plpc: float = 0.0
    asset_class: str = "us_option"
    underlying: str | None = None
    expiry: dt.date | None = None
    strike: float | None = None
    right: Right | None = None

    @property
    def is_option(self) -> bool:
        return self.asset_class == "us_option"

    @property
    def is_short(self) -> bool:
        return self.qty < 0


class AccountSnapshot(Model):
    account_id: str | None = None
    equity: float = 0.0
    last_equity: float = 0.0
    cash: float = 0.0
    buying_power: float = 0.0
    options_buying_power: float | None = None
    options_trading_level: int | None = None
    positions: list[PositionSnapshot] = Field(default_factory=list)
    open_orders: int = 0
    asof: dt.datetime = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))

    @computed_field  # type: ignore[prop-decorator]
    @property
    def day_pl(self) -> float:
        return round(self.equity - self.last_equity, 2)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def day_pl_pct(self) -> float:
        if self.last_equity <= 0:
            return 0.0
        return round((self.equity - self.last_equity) / self.last_equity, 5)

    def option_positions(self) -> list[PositionSnapshot]:
        return [p for p in self.positions if p.is_option]

    def by_underlying(self, symbol: str) -> list[PositionSnapshot]:
        return [p for p in self.positions if (p.underlying or p.symbol) == symbol]


class Decision(Model):
    """One row of the audit trail. Every cycle appends these to the journal.

    This is the artefact the judges read: what the agent saw, what it chose,
    and why - including the trades it declined to make.
    """

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    ts: dt.datetime = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    cycle: str = "manual"
    action: DecisionAction = DecisionAction.SKIP
    symbol: str | None = None
    strategy: str | None = None
    idea: TradeIdea | None = None
    verdict: RiskVerdict | None = None
    fill: Fill | None = None
    rationale: str = ""
    agent_notes: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
