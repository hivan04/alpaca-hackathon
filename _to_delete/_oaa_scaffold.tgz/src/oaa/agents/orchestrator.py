"""The autonomous loop.

One cycle, end to end:

    universe -> market data -> [partner: data_enrichment]
             -> strategies (parallel, independent)
             -> [partner: signal]
             -> critic scores and writes the reasoning
             -> deterministic risk engine (final say, can only reject)
             -> [partner: risk veto]
             -> execution
             -> [partner: telemetry] -> journal

Nothing in here waits for a human. The Autonomy criterion is explicit, so the
only human input is the config file and the decision to start it.
"""

from __future__ import annotations

import datetime as dt
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any

from oaa.agents.critic import Critic
from oaa.agents.llm import get_llm
from oaa.agents.memory import Memory
from oaa.brokers.base import Broker
from oaa.config.loader import Settings
from oaa.core.errors import DataError, StrategyError
from oaa.core.logging import get_logger
from oaa.core.types import (
    AccountSnapshot,
    Decision,
    DecisionAction,
    MarketContext,
    TradeIdea,
)
from oaa.data.base import MarketDataProvider
from oaa.execution.router import ExecutionRouter
from oaa.options.occ import underlying_of
from oaa.partners.base import PartnerHub
from oaa.risk.engine import RiskEngine
from oaa.strategies.base import Strategy, StrategyContext, load_strategies
from oaa.telemetry.journal import Journal

log = get_logger("orchestrator")


@dataclass
class CycleResult:
    cycle: str
    started: dt.datetime
    symbols_scanned: int = 0
    ideas_generated: int = 0
    ideas_approved: int = 0
    orders_placed: int = 0
    positions_closed: int = 0
    errors: list[str] = field(default_factory=list)

    def summary(self) -> str:
        return (
            f"[{self.cycle}] scanned {self.symbols_scanned} | "
            f"ideas {self.ideas_generated} | approved {self.ideas_approved} | "
            f"orders {self.orders_placed} | closed {self.positions_closed}"
            + (f" | errors {len(self.errors)}" if self.errors else "")
        )


class Orchestrator:
    def __init__(
        self,
        settings: Settings,
        broker: Broker,
        data: MarketDataProvider,
        journal: Journal | None = None,
        partners: PartnerHub | None = None,
    ) -> None:
        self.settings = settings
        self.cfg = settings.config
        self.broker = broker
        self.data = data

        settings.ensure_run_dirs()
        t = self.cfg.telemetry
        self.journal = journal or Journal(
            settings.path(t.journal), settings.path(t.db), settings.path(t.equity_curve)
        )
        self.partners = partners or PartnerHub(self.cfg, self.journal)
        self.risk = RiskEngine(self.cfg)
        self.executor = ExecutionRouter(self.cfg, broker)
        self.strategies: list[Strategy] = load_strategies(self.cfg)

        llm = get_llm(self.cfg.agents.llm)
        self.critic = Critic(self.cfg, llm)
        self.memory = (
            Memory(settings.path(self.cfg.agents.memory.path), self.cfg.agents.memory.lookback_days)
            if self.cfg.agents.memory.enabled
            else None
        )

        log.info(
            "orchestrator ready: %d strategies, %d partner adapters, LLM=%s, profile=%s, dry_run=%s",
            len(self.strategies), self.partners.count(), llm.provider,
            self.cfg.profile, self.cfg.execution.dry_run,
        )
        self.journal.event(
            "startup",
            profile=self.cfg.profile,
            broker=self.broker.name,
            strategies=[s.name for s in self.strategies],
            partners=self.partners.stages(),
            llm=llm.provider,
            dry_run=self.cfg.execution.dry_run,
        )

    # ------------------------------------------------------------------ #
    # cycle dispatch
    # ------------------------------------------------------------------ #
    def run_cycle(self, action: str, name: str = "manual") -> CycleResult:
        handlers = {
            "scan_and_trade": self.scan_and_trade,
            "manage_positions": self.manage_positions,
            "report": self.report,
            "flatten": self.flatten,
        }
        handler = handlers.get(action)
        if handler is None:
            raise ValueError(f"unknown cycle action '{action}'")
        result = handler(name)
        log.info(result.summary())
        return result

    # ------------------------------------------------------------------ #
    # scan and trade
    # ------------------------------------------------------------------ #
    def scan_and_trade(self, cycle: str = "scan") -> CycleResult:
        result = CycleResult(cycle=cycle, started=dt.datetime.now(dt.timezone.utc))
        account = self._account_snapshot()
        market_open = self.broker.is_market_open()

        self.risk.observe(account)
        if self.risk.state.halted:
            log.warning("cycle skipped - %s", self.risk.state.halt_reason)
            self.journal.event("halted", reason=self.risk.state.halt_reason, cycle=cycle)
            return result

        symbols = self._symbols_to_scan()
        contexts = self._gather_contexts(symbols)
        result.symbols_scanned = len(contexts)

        candidates: list[tuple[Strategy, TradeIdea, MarketContext]] = []
        for symbol, market in contexts.items():
            for strategy in self.strategies:
                if symbol not in strategy.universe():
                    continue
                ctx = StrategyContext(
                    market=market, account=account, config=self.cfg, params=strategy.params
                )
                try:
                    for idea in strategy.generate(ctx):
                        candidates.append((strategy, idea, market))
                except (StrategyError, DataError) as exc:
                    log.debug("%s/%s: %s", symbol, strategy.name, exc)
                except Exception as exc:  # noqa: BLE001
                    result.errors.append(f"{strategy.name}/{symbol}: {exc}")
                    log.exception("strategy %s failed on %s", strategy.name, symbol)

        # Partner adapters may add or reshape candidates.
        candidates = self.partners.run("signal", candidates) or candidates
        result.ideas_generated = len(candidates)
        if not candidates:
            log.info("[%s] no candidates from %d symbols", cycle, len(contexts))
            return result

        # Best ideas first: a strategy weight times the strategy's own confidence.
        candidates.sort(key=lambda c: -(c[0].weight * c[1].confidence))
        memory_prompt = self.memory.as_prompt() if self.memory else ""

        for strategy, idea, market in candidates:
            decision = Decision(
                cycle=cycle, symbol=idea.symbol, strategy=strategy.name, idea=idea
            )
            try:
                # 1. critic ------------------------------------------------- #
                critique = self.critic.score(
                    idea, market, account,
                    opened_today=self.risk.state.opened_today,
                    memory=memory_prompt,
                )
                idea.score = float(critique.get("score", idea.confidence))
                decision.agent_notes = critique
                decision.rationale = str(critique.get("reasoning", ""))[:2000]

                if not self.critic.accepts(critique):
                    decision.action = DecisionAction.SKIP
                    decision.rationale = (
                        f"critic passed (score {idea.score:.2f} < "
                        f"{self.cfg.agents.critic.min_score_to_trade:.2f}): "
                        + decision.rationale
                    )
                    self.journal.record(decision)
                    continue

                # 2. deterministic risk ------------------------------------- #
                verdict = self.risk.evaluate(idea, account, market_open=market_open)
                decision.verdict = verdict
                if not verdict.approved:
                    decision.action = DecisionAction.SKIP
                    self.journal.record(decision)
                    continue

                # 3. partner veto ------------------------------------------- #
                allowed, veto_reason = self.partners.veto(idea)
                if not allowed:
                    verdict.approved = False
                    verdict.reasons.append(veto_reason or "partner veto")
                    decision.action = DecisionAction.SKIP
                    self.journal.record(decision)
                    continue

                result.ideas_approved += 1

                # 4. execute ------------------------------------------------- #
                execution = self.executor.execute(idea, verdict)
                decision.fill = execution.fill
                decision.action = DecisionAction.OPEN if execution.ok else DecisionAction.SKIP
                if execution.error:
                    decision.error = execution.error
                if execution.ok:
                    result.orders_placed += 1
                    self.risk.record_open()
                    account = self._account_snapshot()

            except Exception as exc:  # noqa: BLE001
                decision.error = str(exc)
                decision.action = DecisionAction.SKIP
                result.errors.append(f"{idea.symbol}: {exc}")
                log.exception("failed processing %s", idea.symbol)

            self.partners.run("telemetry", decision)
            self.journal.record(decision)

        self.journal.snapshot(self._account_snapshot())
        return result

    # ------------------------------------------------------------------ #
    # position management
    # ------------------------------------------------------------------ #
    def manage_positions(self, cycle: str = "manage") -> CycleResult:
        result = CycleResult(cycle=cycle, started=dt.datetime.now(dt.timezone.utc))
        account = self._account_snapshot()
        positions = account.option_positions()
        result.symbols_scanned = len(positions)

        mgmt = self.cfg.management
        today = dt.date.today()

        for position in positions:
            reason: str | None = None
            pnl_pct = position.unrealized_plpc

            if pnl_pct >= mgmt.profit_target_pct:
                reason = f"profit target {mgmt.profit_target_pct:.0%} hit ({pnl_pct:.1%})"
            elif pnl_pct <= -abs(mgmt.stop_loss_pct):
                reason = f"stop loss {mgmt.stop_loss_pct:.0%} hit ({pnl_pct:.1%})"
            elif position.expiry is not None:
                dte = (position.expiry - today).days
                if dte <= mgmt.close_at_dte:
                    reason = f"{dte}d to expiry - closing to avoid assignment risk"

            if reason is None:
                continue

            decision = Decision(
                cycle=cycle,
                action=DecisionAction.CLOSE,
                symbol=position.underlying or underlying_of(position.symbol),
                rationale=reason,
            )
            try:
                fill = self.executor.close(position.symbol, abs(position.qty))
                decision.fill = fill
                result.positions_closed += 1
                log.info("closing %s: %s", position.symbol, reason)
                if self.memory:
                    self.memory.record(
                        symbol=decision.symbol or position.symbol,
                        strategy="managed",
                        structure="leg",
                        pnl=position.unrealized_pl,
                        pnl_pct=pnl_pct,
                        held_days=0.0,
                        thesis=reason,
                    )
            except Exception as exc:  # noqa: BLE001
                decision.error = str(exc)
                result.errors.append(f"close {position.symbol}: {exc}")
                log.exception("failed closing %s", position.symbol)
            self.journal.record(decision)

        self.journal.snapshot(account)
        return result

    # ------------------------------------------------------------------ #
    def flatten(self, cycle: str = "flatten") -> CycleResult:
        """Close everything. Run before the submission deadline so the P&L the
        judges see is realised rather than marked."""
        result = CycleResult(cycle=cycle, started=dt.datetime.now(dt.timezone.utc))
        result.positions_closed = self.executor.flatten_all()
        self.journal.event("flatten", closed=result.positions_closed)
        self.journal.snapshot(self._account_snapshot())
        return result

    def report(self, cycle: str = "report") -> CycleResult:
        result = CycleResult(cycle=cycle, started=dt.datetime.now(dt.timezone.utc))
        account = self._account_snapshot()
        self.journal.snapshot(account)
        self.journal.event(
            "report",
            equity=account.equity,
            day_pl=account.day_pl,
            positions=len(account.positions),
            risk=self.risk.status(),
        )
        log.info(
            "equity $%s | day P&L %+.2f (%.2f%%) | %d positions",
            f"{account.equity:,.2f}", account.day_pl,
            account.day_pl_pct * 100, len(account.positions),
        )
        return result

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #
    def _account_snapshot(self) -> AccountSnapshot:
        return self.broker.account()

    def _symbols_to_scan(self) -> list[str]:
        symbols: set[str] = set()
        for strategy in self.strategies:
            symbols.update(strategy.universe())
        universe = set(self.cfg.universe.active())
        return sorted(symbols & universe) if universe else sorted(symbols)

    def _gather_contexts(self, symbols: list[str]) -> dict[str, MarketContext]:
        """Fetch market data in parallel, then let partners enrich it.

        Threads, not async: the Alpaca SDK is synchronous and the rate limiter
        is shared, so this is bounded by the API budget rather than by CPU.
        """
        contexts: dict[str, MarketContext] = {}
        workers = min(4, max(1, len(symbols)))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(self.data.context, symbol): symbol for symbol in symbols}
            for future in as_completed(futures):
                symbol = futures[future]
                try:
                    contexts[symbol] = future.result()
                except DataError as exc:
                    log.warning("no data for %s: %s", symbol, exc)
                except Exception as exc:  # noqa: BLE001
                    log.exception("context fetch failed for %s: %s", symbol, exc)

        for symbol, market in list(contexts.items()):
            enriched = self.partners.run("data_enrichment", market)
            if isinstance(enriched, MarketContext):
                contexts[symbol] = enriched
        return contexts

    def status(self) -> dict[str, Any]:
        account = self._account_snapshot()
        return {
            "profile": self.cfg.profile,
            "broker": self.broker.name,
            "dry_run": self.cfg.execution.dry_run,
            "market_open": self.broker.is_market_open(),
            "equity": account.equity,
            "day_pl": account.day_pl,
            "positions": len(account.positions),
            "strategies": [s.name for s in self.strategies],
            "partners": self.partners.stages(),
            "risk": self.risk.status(),
            "counts": self.journal.counts(),
        }

    def close(self) -> None:
        self.partners.teardown()
        self.broker.close()
