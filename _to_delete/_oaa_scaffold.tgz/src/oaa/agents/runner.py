"""The always-on scheduler.

`oaa run` starts this and walks away. It wakes itself on the cycle times in
config, monitors positions in between, and keeps going across days without
supervision.

Deliberately dependency-free (no APScheduler): one loop, one sleep, easy to
reason about at 2am when something is wrong.
"""

from __future__ import annotations

import datetime as dt
import signal
import time
from typing import Any

from oaa.agents.orchestrator import Orchestrator
from oaa.core.logging import get_logger

log = get_logger("runner")

_DAY_INDEX = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}


class Runner:
    def __init__(self, orchestrator: Orchestrator) -> None:
        self.orch = orchestrator
        self.cfg = orchestrator.cfg
        self.schedule = self.cfg.schedule
        self._stop = False
        self._fired: set[tuple[dt.date, str]] = set()
        self._last_monitor = 0.0

    # -- signals ------------------------------------------------------------ #
    def install_signal_handlers(self) -> None:
        def handle(signum: int, _frame: Any) -> None:
            log.info("signal %s received - finishing current cycle then stopping", signum)
            self._stop = True

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, handle)
            except (ValueError, OSError):  # not on the main thread
                pass

    # -- time --------------------------------------------------------------- #
    def _now(self) -> dt.datetime:
        try:
            from zoneinfo import ZoneInfo

            return dt.datetime.now(ZoneInfo(self.schedule.timezone))
        except Exception:  # noqa: BLE001
            return dt.datetime.now()

    def _is_trading_day(self, now: dt.datetime) -> bool:
        allowed = {_DAY_INDEX[d.lower()[:3]] for d in self.schedule.trading_days}
        return now.weekday() in allowed

    def _due(self, now: dt.datetime) -> list[Any]:
        """Cycles whose time has passed today and which have not yet fired.

        Late-firing is intentional: if the process restarts at 10:15 the 09:45
        scan still runs, rather than being silently skipped for the day.
        """
        due = []
        for cycle in self.schedule.cycles:
            key = (now.date(), cycle.name)
            if key in self._fired:
                continue
            hour, minute = (int(part) for part in cycle.at.split(":"))
            scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if now >= scheduled:
                due.append(cycle)
        return due

    # -- main loop ----------------------------------------------------------- #
    def run(self, once: bool = False, poll_seconds: int = 20) -> None:
        self.install_signal_handlers()
        log.info(
            "runner started: %d cycles, timezone %s, monitor every %ds",
            len(self.schedule.cycles), self.schedule.timezone,
            self.schedule.monitor_interval_seconds,
        )
        self.orch.journal.event("runner_start", cycles=[c.name for c in self.schedule.cycles])

        while not self._stop:
            now = self._now()

            if self._is_trading_day(now):
                for cycle in self._due(now):
                    log.info("--- cycle '%s' (%s) ---", cycle.name, cycle.action)
                    try:
                        self.orch.run_cycle(cycle.action, cycle.name)
                    except Exception as exc:  # noqa: BLE001 - a bad cycle must
                        # never kill the process; tomorrow's cycles still matter.
                        log.exception("cycle '%s' failed: %s", cycle.name, exc)
                        self.orch.journal.event("cycle_error", cycle=cycle.name, error=str(exc))
                    self._fired.add((now.date(), cycle.name))

                self._monitor()

            if once:
                break
            time.sleep(poll_seconds)

        log.info("runner stopped")
        self.orch.journal.event("runner_stop")

    def _monitor(self) -> None:
        interval = self.schedule.monitor_interval_seconds
        if interval <= 0 or time.monotonic() - self._last_monitor < interval:
            return
        self._last_monitor = time.monotonic()
        try:
            self.orch.journal.snapshot(self.orch.broker.account())
        except Exception as exc:  # noqa: BLE001
            log.warning("snapshot failed: %s", exc)
