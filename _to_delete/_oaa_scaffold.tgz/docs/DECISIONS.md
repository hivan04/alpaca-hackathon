# Design decisions

Short record of the choices that are not obvious, and why. Useful for the deck —
"Creativity & Originality" is scored on the thinking, not the line count.

### Defined risk only, enforced in code

`risk.allow_undefined_risk` defaults to false and the risk engine refuses any
structure whose `max_loss` is not computable. P&L is scored over a single week; one
uncapped loss ends the run. Every shipped strategy returns a structure with a
calculated maximum loss, and the engine checks rather than trusts.

### The LLM never approves anything

The critic scores ideas and writes the reasoning. The deterministic risk engine emits
a signed stamp, and execution refuses tickets without one. If the LLM is down, the
loop degrades to a transparent heuristic score and keeps trading — uptime is worth
more than prose in a P&L-scored week.

### Two strategies that fire on opposite regimes

`vol_carry_condor` wants rich IV and no trend. `momentum_debit_spread` wants a
confirmed trend and cheap IV. They are near-mutually-exclusive by construction, so
the book gets diversification from one universe rather than from two correlated bets.
There is a test asserting exactly this.

### Sizing from max loss, not from capital

`size_by_risk` divides the per-trade risk budget by the structure's own maximum loss.
Every position therefore risks the same fraction of equity regardless of how wide the
spread is — which is the property that makes a hit-rate strategy survive a bad day.

### Deterministic client order IDs

`client_order_id = sha256(idea.id | symbol | structure | qty | step)`. A retry after
an ambiguous failure produces the same ID, and the router checks for an existing
order before resubmitting. Double-fills are the classic way an autonomous agent
destroys a paper account overnight.

### Chase the fill, but bound the slippage

Multi-leg limits at mid frequently do not fill. The router walks the price toward the
far touch over `chase.steps`, cancelling between attempts, and logs a warning past
`max_slippage_pct`. Filling at mid in the backtest and crossing the spread live is
how a strategy looks profitable on paper and is not.

### Four broker backends behind one protocol

The event rewards MCP *or* CLI usage. Rather than pick one and bolt the other on for
the demo, all four (`rest`, `cli`, `mcp`, `sim`) implement the same `Broker`
protocol, so any of them can run the real loop. `sim` also means the entire pipeline
is testable offline.

### The journal records rejections

Most agent projects log what they did. The interesting artefact is what the system
*refused* to do and which rule stopped it — that is the evidence that the risk layer
is real, and it is the most compelling thing to put on screen in the demo video.

### The backtest is a replay harness, and says so

Alpaca's free tier has no full historical option chain with greeks. The engine
replays the real strategy, risk and execution code over supplied contexts with a
conservative fill model. It catches bugs and produces a curve; it is not evidence of
edge, and the deck should not claim it is. The judged number is live paper P&L.

### Partner adapters can only veto

Sponsor technology plugs into seven named pipeline stages. At the `risk` stage an
adapter can block a trade but never approve one. A third-party SDK cannot widen the
risk envelope — which is what makes it safe to integrate one under time pressure on
day one of the event.
