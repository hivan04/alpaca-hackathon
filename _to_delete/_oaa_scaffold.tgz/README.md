# Options Alpha Agents

Autonomous options trading agents on Alpaca. Built for the
[Alpaca AI Trading Agents Hackathon](https://lablab.ai/ai-hackathons/alpaca-ai-trading-agents-hackathon)
— **Options Alpha Agents** track.

Specialist strategies propose defined-risk options structures, an LLM critic scores
them and writes the reasoning, a deterministic Python risk engine has the final veto,
and the whole loop runs unattended against Alpaca paper trading over the Trading API,
the MCP server, or the CLI.

---

## Quick start

```bash
git clone <this repo> && cd alpaca-hackathon
make setup                 # venv, deps, .env, config/local.yaml
# fill in .env with BOTH paper key pairs
./scripts/install_tools.sh # alpaca CLI, uvx, MCP server, agent skills
make doctor                # verifies every dependency and credential
make scan                  # a dry cycle: what would the agent do right now?
make run                   # the autonomous loop
```

`make doctor` is the command to trust. It checks config, packages, the `alpaca`
binary, `uvx`, both credential sets, the live connection, your options trading level,
and whether the market is open.

---

## What it does

| Requirement | How it is met |
|---|---|
| **Autonomous agents** | `oaa run` schedules its own cycles, decides and acts with no human gate, survives failed cycles and restarts |
| **MCP or CLI** | Both. `broker.primary: mcp` speaks to `alpaca-mcp-server`; `cli` drives the `alpaca` binary. The LLM agent calls MCP tools directly |
| **Options trading** | Every strategy emits a multi-leg options structure with a computed maximum loss. No equity legs, no naked shorts |

### Shipped strategies

| Strategy | Structure | Fires when |
|---|---|---|
| `vol_carry_condor` | iron condor (4 legs, net credit) | IV rank rich, IV/RV > 1.1, no strong trend |
| `momentum_debit_spread` | vertical debit spread (2 legs) | confirmed trend, ADX above floor, IV cheap |
| `earnings_calendar` | calendar spread | *(off by default)* term-structure inversion into an earnings print |

The first two fire on deliberately opposite regimes, so the book diversifies from one
universe rather than doubling down.

---

## Layout

```
config/                  every knob, in YAML
  default.yaml           the master file
  dev.yaml               throwaway account overlay
  judged.yaml            the account judges evaluate
  strategies/*.yaml      per-strategy parameters

src/oaa/
  config/                load, merge, validate; credential resolution
  core/                  domain types, registry, logging
  options/               OCC symbols, chain filtering, structure builders
  data/                  market data providers, indicators
  strategies/            signal -> structure  (add a file, add a config block)
  risk/                  hard limits and sizing  (the only thing that can approve)
  execution/             pricing, idempotency, order routing
  brokers/               rest | cli | mcp | sim, one protocol
  agents/                LLM, critic, memory, orchestrator, scheduler
  partners/              sponsor technology adapters
  telemetry/             journal, metrics, HTML report
  app/                   read-only public dashboard
  backtest/              replay harness

docs/ARCHITECTURE.md     the diagram and the reasoning
docs/RUNBOOK.md          day-to-day operation and kill switches
docs/PARTNERS.md         wiring in a technology partner at kickoff
docs/DECISIONS.md        why the non-obvious choices were made
```

---

## Commands

```
oaa doctor          check every dependency and credential
oaa account         account, options level, positions
oaa chain SPY       inspect the filtered chain a strategy actually sees
oaa scan            one dry cycle
oaa trade           one live cycle
oaa run             the autonomous loop
oaa manage          apply exit rules to open positions
oaa flatten         close everything
oaa report          performance report -> JSON + self-contained HTML
oaa journal         recent decisions, including the declined ones
oaa partners        technology-partner adapters and their stages
oaa mcp-tools       list the tools the Alpaca MCP server exposes
oaa strategies      registered strategies
oaa config-dump     the fully merged configuration
oaa serve           the public dashboard (the submission's Application URL)
```

---

## Configuration

One YAML file drives everything. Merge order, later wins:

```
config/default.yaml -> config/<profile>.yaml -> config/local.yaml -> OAA_* env vars
```

Environment overrides use double underscores for nesting:

```bash
OAA_RISK__MAX_RISK_PER_TRADE_PCT=0.01 oaa run
```

### Two accounts, always

`profile: dev` uses `ALPACA_DEV_*` keys; `profile: judged` uses `ALPACA_*`. The judged
account is the one whose full history the judges read, so all debugging happens in
dev. `./scripts/verify_accounts.sh` confirms they are genuinely different accounts
before you point the agent at the judged one.

---

## Safety model

- **Only `RiskEngine` approves.** It emits a signed stamp; the execution router
  refuses any ticket without one. The LLM scores and explains — it cannot authorise.
- **Defined risk enforced in code.** Structures without a computable maximum loss are
  rejected outright.
- **Idempotent orders.** Deterministic `client_order_id`s plus a pre-submit existence
  check, so an ambiguous failure can never double-fill.
- **Self-halting.** Daily loss limit and max drawdown stop trading automatically, and
  the halt is recorded in the journal.
- **Dry run by default.** `execution.dry_run: true` in the dev profile logs the exact
  order payload without sending it.

---

## Extending

**A strategy** — new file in `src/oaa/strategies/`, subclass `Strategy`, decorate with
`@strategy_registry.register("name")`, add a params YAML, add a config block.

**A technology partner** — copy `src/oaa/partners/example_partner.py`, pick one of the
seven pipeline stages, add a config block. See `docs/PARTNERS.md`.

**A broker or data provider** — implement the protocol, decorate with the registry,
change one config line.

Nothing in the core pipeline changes for any of the three.

---

## Development

```bash
make test     # 74 tests, no network required
make lint     # ruff
make check    # both
```

The `sim` broker and the synthetic Black-Scholes chain fixture mean the entire
pipeline — strategies, risk, execution, telemetry — is tested offline.

## Licence

MIT. See `LICENSE`.
